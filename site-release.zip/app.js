'use strict';
(() => {
  const data = window.BRIEF_DATA;
  const $ = (id) => document.getElementById(id);
  const video = $('evidenceVideo'), canvas = $('featureChart'), ctx = canvas.getContext('2d');
  const slider = $('timeSlider');
  const colors = ['#b6e2a3', '#f0a4a4'];
  let example, raf = 0, dragging = false, wasPlaying = false, rect = null;
  const descriptions = {
    R01: {title:'Kinetic energy rises with motion variability', reading:'The amount of measured movement and its variability both rise over the selected interval. Across the corpus, this relation has 28 occurrences in 18 film clips.'},
    R03: {title:'Visual complexity rises with human presence', reading:'Clutter and the detector-based human-presence signal rise together. This relation has 17 occurrences in 14 film clips.'},
    R04: {title:'Human presence falls as framing closeness rises', reading:'Detector-based presence decreases while the ordinal framing signal moves toward closer views. This relation has 18 occurrences in 16 film clips.'}
  };
  const format = (s) => {s=Math.max(0,Math.floor(s||0));return `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;};
  const icons = () => {if(window.lucide) window.lucide.createIcons({nameAttr:'data-icon',attrs:{class:'icon','aria-hidden':'true','stroke-width':1.7}});};
  function valueAt(curve, time) {
    const points=curve.points;
    // Hold the observed per-second value; the source contains no sub-second measurements.
    const point=points.find(p=>p.t===Math.floor(time)) || points[points.length-1];
    return point && point.v!==null ? point.v : null;
  }
  function currentTime(){return example.offset+(Number.isFinite(video.currentTime)?video.currentTime:0);}
  function draw() {
    if(!example || !ctx) return;
    const w=canvas.clientWidth, h=canvas.clientHeight, ratio=window.devicePixelRatio||1;
    if(canvas.width!==Math.round(w*ratio)||canvas.height!==Math.round(h*ratio)){canvas.width=Math.round(w*ratio);canvas.height=Math.round(h*ratio);}
    ctx.setTransform(ratio,0,0,ratio,0,0);ctx.clearRect(0,0,w,h);
    const values=example.curves.flatMap(c=>c.points.map(p=>p.v).filter(v=>v!==null));
    let min=Math.min(0,...values),max=Math.max(0,...values);
    const pad=Math.max((max-min)*.12,.25);min-=pad;max+=pad;
    const left=36,right=w-12,top=14,bottom=h-28;
    rect={left,right,top,bottom,width:w};
    const x=t=>left+(t-example.offset)/(example.end-example.offset)*(right-left);
    const y=v=>bottom-(v-min)/(max-min)*(bottom-top);
    ctx.fillStyle='rgba(190,221,157,.09)';ctx.fillRect(x(example.motifStart),top,x(example.motifEnd)-x(example.motifStart),bottom-top);
    ctx.font='10px Segoe UI, Arial';ctx.textBaseline='middle';
    for(let i=0;i<4;i++){
      const val=min+(max-min)*i/3, yy=y(val);
      ctx.strokeStyle='#354847';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(left,yy);ctx.lineTo(right,yy);ctx.stroke();
      ctx.fillStyle='#96aba6';ctx.textAlign='right';ctx.fillText(val.toFixed(1),left-8,yy);
    }
    if(min<0&&max>0){ctx.setLineDash([3,4]);ctx.strokeStyle='#6e8379';ctx.beginPath();ctx.moveTo(left,y(0));ctx.lineTo(right,y(0));ctx.stroke();ctx.setLineDash([]);}
    example.curves.forEach((curve,i)=>{
      ctx.strokeStyle=colors[i];ctx.lineWidth=2.3;ctx.lineJoin='round';ctx.beginPath();let active=false;
      curve.points.forEach(p=>{if(p.v===null){active=false;return;}if(!active){ctx.moveTo(x(p.t),y(p.v));active=true;}else ctx.lineTo(x(p.t),y(p.v));});ctx.stroke();
    });
    ctx.textAlign='left';ctx.fillStyle='#9db3ab';ctx.fillText(format(example.offset),left,bottom+18);
    ctx.textAlign='center';ctx.fillText(format((example.offset+example.end)/2),(left+right)/2,bottom+18);
    ctx.textAlign='right';ctx.fillText(format(example.end),right,bottom+18);
    const now=currentTime(), cursor=Math.max(left,Math.min(right,x(now)));
    ctx.strokeStyle='#e7f2e4';ctx.lineWidth=1.5;ctx.setLineDash([5,4]);ctx.beginPath();ctx.moveTo(cursor,top);ctx.lineTo(cursor,bottom);ctx.stroke();ctx.setLineDash([]);
    ctx.fillStyle='#e7f2e4';ctx.beginPath();ctx.arc(cursor,bottom,4,0,Math.PI*2);ctx.fill();
    if(!dragging)slider.value=String(video.currentTime||0);
    $('clock').textContent=format(now);
    $('clipTime').textContent=`Clip time ${format(now)} / ${format(example.end)}`;
    const inEpisode=now>=example.motifStart&&now<=example.motifEnd;
    $('episodeState').textContent=`${example.motif} · ${format(example.motifStart)}–${format(example.motifEnd)} · ${inEpisode?'within episode':now<example.motifStart?'context before episode':'context after episode'}`;
    example.curves.forEach((curve,i)=>{const val=valueAt(curve,now);$(`value${i}`).textContent=val===null?'—':val.toFixed(2);});
  }
  function tick(){
    if($('loopEpisode').checked && currentTime()>example.motifEnd && !dragging){video.currentTime=example.motifStart-example.offset;}
    draw();
    if(!video.paused&&!video.ended)raf=requestAnimationFrame(tick);
  }
  function seek(seconds){
    const max=Number.isFinite(video.duration)?video.duration:example.end-example.offset;
    video.currentTime=Math.max(0,Math.min(max,seconds));draw();
  }
  function loadExample(id){
    const next=data.examples.find(e=>e.id===id);if(!next)return;
    video.pause();cancelAnimationFrame(raf);example=next;
    $('videoError').hidden=true;
    $('filmCredit').textContent=`${example.film} (${example.year}) · excerpt from corpus clip`;
    $('legend').innerHTML=example.curves.map((c,i)=>`<span><i class="swatch" style="--color:${colors[i]}"></i>${c.label}<b id="value${i}"></b></span>`).join('');
    $('localMetrics').innerHTML=`<div><strong>${example.metrics.duration}s</strong><span>selected interval</span></div><div><strong>${example.metrics.rho.toFixed(2)}</strong><span>synchronized change (rho)</span></div><div><strong>${example.metrics.tau_a.toFixed(2)}</strong><span>direction consistency A</span></div><div><strong>${example.metrics.tau_b.toFixed(2)}</strong><span>direction consistency B</span></div>`;
    slider.max=String(example.end-example.offset);slider.value='0';
    video.poster=example.poster;video.src=example.video;video.load();draw();
  }
  function loadMotif(mid){
    const copy=descriptions[mid];
    document.querySelectorAll('[data-motif]').forEach(b=>{b.setAttribute('aria-selected',String(b.dataset.motif===mid));b.tabIndex=b.dataset.motif===mid?0:-1;});
    $('evidencePanel').setAttribute('aria-labelledby',`tab-${mid}`);
    $('exampleTitle').textContent=copy.title;$('exampleReading').textContent=copy.reading;
    const choices=data.examples.filter(e=>e.motif===mid);
    $('exampleSelect').innerHTML=choices.map(e=>`<option value="${e.id}">${e.film} (${e.year})</option>`).join('');
    $('exampleSelect').closest('.film-picker').hidden=choices.length<2;
    loadExample(choices[0].id);
  }
  document.querySelectorAll('[data-motif]').forEach(b=>b.addEventListener('click',()=>loadMotif(b.dataset.motif)));
  $('exampleSelect').addEventListener('change',e=>loadExample(e.target.value));
  slider.addEventListener('input',()=>seek(Number(slider.value)));
  $('restartMotif').addEventListener('click',()=>{seek(example.motifStart-example.offset);video.play().catch(()=>{});});
  $('loopEpisode').addEventListener('change',()=>{if($('loopEpisode').checked)seek(example.motifStart-example.offset);});
  video.addEventListener('play',()=>{cancelAnimationFrame(raf);raf=requestAnimationFrame(tick);});
  ['pause','seeked','timeupdate','loadedmetadata','ended'].forEach(event=>video.addEventListener(event,draw));
  video.addEventListener('error',()=>{$('videoError').hidden=false;});
  function seekPointer(event){if(!rect)return;const bounds=canvas.getBoundingClientRect();const relative=(event.clientX-bounds.left-rect.left)/(rect.right-rect.left);seek(Math.max(0,Math.min(1,relative))*(example.end-example.offset));}
  canvas.addEventListener('pointerdown',event=>{dragging=true;wasPlaying=!video.paused;video.pause();canvas.setPointerCapture(event.pointerId);seekPointer(event);});
  canvas.addEventListener('pointermove',event=>{if(dragging)seekPointer(event);});
  function endDrag(){if(!dragging)return;dragging=false;if(wasPlaying)video.play().catch(()=>{});draw();}
  canvas.addEventListener('pointerup',endDrag);canvas.addEventListener('pointercancel',endDrag);
  new ResizeObserver(draw).observe(canvas);

  $('reelGrid').innerHTML=data.reels.map(r=>{const ex=data.examples.find(e=>e.motif===r.id);return `<article class="reel-item"><h4>${r.id} / ${r.id==='R01'?'Motion together':r.id==='R03'?'People & complexity':'Opposing trends'}</h4><p>${r.title}</p><video controls playsinline preload="none" poster="${ex.poster}" src="${r.video}" aria-label="${r.id} evidence reel"></video><small>${Math.round(r.duration)} seconds · ${r.segments.length} complete examples · source clip times on title cards</small></article>`;}).join('');
  // One audio source at a time, including the interactive example.
  document.addEventListener('play',event=>{if(event.target.tagName==='VIDEO')document.querySelectorAll('video').forEach(v=>{if(v!==event.target)v.pause();});},true);
  const screens={scene:{alt:'Actual platform scene view with video, graph, and motif timeline',caption:'Scene analysis: inspect the video, follow feature changes, and return to each retained motif interval.'},discoveries:{alt:'Actual platform discoveries page listing relation candidates and corpus evidence',caption:'Cross-film discovery: inspect recurring candidates, film coverage, and exact occurrences.'}};
  document.querySelectorAll('[data-screen]').forEach(b=>b.addEventListener('click',()=>{const s=screens[b.dataset.screen];$('platformScreen').src=`assets/screenshots/${b.dataset.screen}.png`;$('platformScreen').alt=s.alt;$('platformCaption').textContent=s.caption;selectTab(b);}));
  const figures={ranking:{file:'relation_motif_rankings',alt:'Relation candidates ranked by descriptive motif score',caption:'Candidate ranking across the current corpus, providing a comparative view of the strongest recurring relations.'},distribution:{file:'relation_episode_distributions',alt:'Distributions across the retained relation episodes',caption:'Distributions across the retained episodes show how duration and relation characteristics vary throughout the corpus.'},breadth:{file:'relation_recurrence_vs_strength',alt:'Film coverage versus median local relation strength',caption:'A comparative view of recurrence across films and the relative strength of each candidate relation.'}};
  function loadFigure(key){const f=figures[key];$('resultFigure').src=`assets/charts/${f.file}.png`;$('resultFigure').alt=f.alt;$('resultCaption').textContent=f.caption;$('downloadFigure').href=`assets/charts/${f.file}.png`;}
  document.querySelectorAll('[data-figure]').forEach(b=>b.addEventListener('click',()=>{selectTab(b);loadFigure(b.dataset.figure);}));
  function selectTab(button){button.parentElement.querySelectorAll('[role=tab]').forEach(b=>{b.setAttribute('aria-selected',String(b===button));b.tabIndex=b===button?0:-1;});}
  document.querySelectorAll('[role=tablist]').forEach(list=>list.addEventListener('keydown',event=>{
    if(!['ArrowRight','ArrowLeft','Home','End'].includes(event.key))return;
    const buttons=Array.from(list.querySelectorAll('[role=tab]')),index=buttons.indexOf(document.activeElement);
    if(index<0)return;event.preventDefault();let next=event.key==='Home'?0:event.key==='End'?buttons.length-1:(index+(event.key==='ArrowRight'?1:-1)+buttons.length)%buttons.length;buttons[next].focus();buttons[next].click();
  }));
  $('candidateRows').innerHTML=data.motifs.map(m=>`<tr><td>${m.motif_id}</td><td>${m.title}</td><td>${m.count}</td><td>${m.number_of_films}</td><td>${m.median_duration}s</td><td>${m.motif_score.toFixed(2)}</td></tr>`).join('');
  $('menuButton').addEventListener('click',()=>{const open=$('navigation').classList.toggle('open');$('menuButton').setAttribute('aria-expanded',String(open));$('menuButton').setAttribute('aria-label',open?'Close navigation':'Open navigation');});
  $('navigation').querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{$('navigation').classList.remove('open');$('menuButton').setAttribute('aria-expanded','false');}));
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){$('navigation').classList.remove('open');$('menuButton').setAttribute('aria-expanded','false');}});
  const observed=new IntersectionObserver(entries=>{for(const entry of entries)if(entry.isIntersecting)document.querySelectorAll('nav a').forEach(a=>a.classList.toggle('active',a.hash===`#${entry.target.id}`));},{rootMargin:'-20% 0px -60% 0px'});
  ['evidence','method','findings','questions'].forEach(id=>observed.observe($(id)));
  icons();loadMotif('R01');loadFigure('ranking');
})();
